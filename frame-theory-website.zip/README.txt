FRAME THEORY WEBSITE

To preview: open index.html in your browser.

Free publishing with GitHub Pages:
1. Create a free GitHub account.
2. Create a PUBLIC repository named frame-theory.
3. Upload index.html and the images folder from this ZIP to the repository root.
4. In repository Settings > Pages, choose Deploy from a branch, main, /(root), and Save.
5. Your website will appear at https://YOUR-USERNAME.github.io/frame-theory/ after deployment.

You can replace images in the images folder and update captions in index.html.
